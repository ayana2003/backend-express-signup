// var express = require('express');
// var router = express.Router();
// var models = require("../models");
// const posts = require('../models/posts');
// var authService = require("../services/auth");
// const mysql = require('mysql2');

var express = require("express");
var router = express.Router();
var models = require("../models"); //<--- Add models
var authService = require("../services/auth"); //<--- Add authentication service

// router.get("/", function (req, res, next) {
//   let token = req.cookies.jwt;
//   if (token) {
//     authService.verifyUser(token)
//       .then(user => {
//         if (user) {
//           models.posts.findAll({
//             where: { UserId: user.UserId, Deleted: false }
//           })
//             .then(result => res.render("posts", { posts: result }));
//           //console.log(user.posts);
//           //res.render("posts", { posts: user.posts });
//           //res.send(JSON.stringify(user));
//         } else {
//           res.status(401);
//           res.send("Invalid authentication token");
//         }
//       });
//   } else {
//     res.status(401);
//     res.send("Must be logged in");
//   }
// });
// router.get("/posts", function(req, res, next) {
//     res.render("posts");
//   });

router.get('/', function (req, res, next) {
    let token = req.cookies.jwt;
    authService.verifyUser(token)
      .then(user => {
        if (user) {
          models.posts.findAll({
            where: { UserId: user.UserId }
          })
            .then(result => res.render('posts', {
              posts: result
            }))
        } else {
          res.status(401);
          res.send('Please log in to view posts')
        }
      })
  });
  
  //-------------------------------------------------
  //-------------------------------------------------
  //-------------------------------------------------
  
  router.get("/:id", function (req, res, next) {
    let postId = parseInt(req.params.id);
    models.posts.findOne({ where: { PostId: postId }, raw: true }).then(post => {
      console.log(post);
      res.render("editPost", post);
    });
  });
  
  router.post("/", function (req, res, next) {
    let token = req.cookies.jwt;
    if (token) {
      authService.verifyUser(token).then(user => {
        if (user) {
          models.posts
            .findOrCreate({
              where: {
                UserId: user.UserId,
                PostTitle: req.body.postTitle,
                PostBody: req.body.postBody
              }
            })
            .spread((result, created) => res.redirect("/posts"));
        } else {
          res.status(401);
          res.send("Invalid authentication token");
        }
      });
    } else {
      res.status(401);
      res.send("Must be logged in");
    }
  });
  
  router.delete("/:id", function (req, res, next) {
    let postId = parseInt(req.params.id);
    models.posts
      .update(
        { Deleted: true },
        {
          where: { PostId: postId }
        }
      )
      .then(result => res.redirect("/"));
  });
  
  router.put("/:id", function (req, res, next) {
    let postId = parseInt(req.params.id);
    console.log(req.body);
    console.log(postId);
    models.posts
      .update(req.body, { where: { PostId: postId } })
      .then(result => res.redirect("/"));
  });
  

// router.get('/posts', function(req, res, next) {
//     models.posts.findAll({}).then(postsFound => {
//       res.render('posts', {
//         posts: postsFound
//       });
//     });
//   });

//   router.get('/posts', function(req, res, next) {
//     models.actor
//       .findAll({ 
//         attributes: ['actor_id', 'first_name', 'last_name'],
//         include: [{ 
//           model: models.film, 
//           attributes: ['film_id', 'title', 'description', 'rental_rate', 'rating'] 
//         }]      
//       })
//       .then(actorsFound => {
//         res.setHeader('Content-Type', 'application/json');
//         res.send(JSON.stringify(actorsFound));
//       });
//   });

//   router.post("/posts", function(req, res, next) {
//     models.posts.findOrCreate({
//       where: { PostTitle: req.body.PostTitle, PostBody: req.body.PostBody}
//     //   defaults: {
        
//     //     // LastName: req.body.lastName,
//     //     // Email: req.body.email,
//     //     // Password: authService.hashPassword(req.body.password) 
//     //     // //Password: req.body.password 
//     //   }
//     })
//     .spread(function(result, created) {
//       if(created) {
//         res.send("Post created");
//       } else {
//         res.send("This post already exists!");
//       }
//     });
//   });

// router.post('/profile', function(req, res, next) {
//     let bodyPost = req.body.posts;
//     if (posts.includes(bodyPost.posts)) {
//       res.send('We already have that post, no need to add it');
//     } else {
//       posts.push(bodyPost.post);
//       res.send(posts);
//     }
//   });

//   router.post('/profile', function(req, res, next) {
//     console.log(req.body);
//     const newPost = {
//         PostTitle: req.body.postTitle,
//         PostBody: req.body.postBody
//     };
  
//     const selectPost = `SELECT *
//       FROM posts
//       WHERE PostTitle = '${newPost.PostTitle}'
//       AND PostBody = '${newPost.PostBody}'`;
  
//     connection.query(selectPost, function(err, result) {
//       if (result.length > 0) {
//         res.send('Sorry, that post already exists');
//       } else {
//         let newPostQuery = `INSERT INTO posts(PostTitle, PostBody) 
//           VALUES('${newPost.PostTitle}', '${newPost.PostBody}')`;
  
//         connection.query(newPostQuery, function(err, insertResult) {
//           if (err) {
//             res.render('error', { message: 'Oops, something went wrong!' });
//           } else {
//             res.render('/profile');
//           }
//         });
//       }
//     });
//   });

//   router.post('/profile', function(req, res, next) {
//     models.posts
//       .findOrCreate({
//         where: {
//           PostTitle: req.body.postTitle,
//           PostBody: req.body.postBody
//         }
//         // ,
//         // defaults: {
          
      
//         // }
//       })
//       .spread(function(result, created) {
//         if (created) {
//           res.render('Post successfully created');
//           //res.send(PostTitle);
//         } else {
//           res.render('This post already exists');
//         }
//       });
//   });

  // router.post('/logout', function (req, res, next) {
//   models.posts.create(req.body)
//     .then(newPost => {
//       res.setHeader('Content-Type', 'application/json');
//       res.send(JSON.stringify(newPost));
//     })
//     .catch(err => {
//       res.status(400);
//       res.send(err.message);
//     });
// });


  module.exports = router;